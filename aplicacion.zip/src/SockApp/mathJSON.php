<?php 
namespace SockApp;
$txt='[
{
"name": "level 1",
	"exercise":[
		{"ex":"2+2","res":4},
		{"ex":"5+4","res":9},
		{"ex":"6+6","res":12},
		{"ex":"7+7","res":14},
		{"ex":"8+8","res":16}
	]
},
{
"name": "level 2",
	"exercise":[
		{"ex":"12/6","res":2},
		{"ex":"20/5","res":4},
		{"ex":"30/6","res":5},
		{"ex":"50/2","res":25},
		{"ex":"30*6","res":180}
	]
},
{
"name": "level 3",
	"exercise":[
		{"ex":"12*6","res":72},
		{"ex":"22*3","res":66},
		{"ex":"54*4","res":216},
		{"ex":"37*3","res":111},
		{"ex":"79*4","res":316}
	]
}
]';



 ?>